import unittest
from app import app

class DOPCTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()

    def test_missing_params(self):
        response = self.app.get('/api/v1/delivery-order-price')
        self.assertEqual(response.status_code, 400)

    def test_invalid_venue(self):
        response = self.app.get('/api/v1/delivery-order-price?venue_slug=invalid&cart_value=1000&user_lat=60.17&user_lon=24.93')
        self.assertEqual(response.status_code, 500)

    # Add more tests for valid cases and edge cases

if __name__ == '__main__':
    unittest.main()

