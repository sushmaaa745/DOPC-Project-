import requests
from math import radians, cos, sin, sqrt, atan2

# Haversine formula for calculating straight-line distance
def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371 * 1000  # Radius of Earth in meters
    d_lat = radians(lat2 - lat1)
    d_lon = radians(lon2 - lon1)
    a = sin(d_lat / 2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(d_lon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return R * c

# Fetch static data
def fetch_static_data(venue_slug):
    url = f"https://consumer-api.development.dev.woltapi.com/home-assignment-api/v1/venues/{venue_slug}/static"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception("Failed to fetch static data")
    return response.json()

# Fetch dynamic data
def fetch_dynamic_data(venue_slug):
    url = f"https://consumer-api.development.dev.woltapi.com/home-assignment-api/v1/venues/{venue_slug}/dynamic"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception("Failed to fetch dynamic data")
    return response.json()
 
