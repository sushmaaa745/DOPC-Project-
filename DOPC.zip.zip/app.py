from flask import Flask, request, jsonify
from utils import calculate_distance, fetch_static_data, fetch_dynamic_data

app = Flask(__name__)

@app.route('/')
def index():
    return "Welcome to the Delivery Order Price Calculator Service!"

@app.route('/api/v1/delivery-order-price', methods=['GET'])
def delivery_order_price():
    try:
        # Parse query parameters
        venue_slug = request.args.get('venue_slug')
        cart_value = int(request.args.get('cart_value'))
        user_lat = float(request.args.get('user_lat'))
        user_lon = float(request.args.get('user_lon'))

        if not all([venue_slug, cart_value, user_lat, user_lon]):
            return jsonify({"error": "Missing required parameters"}), 400

        # Fetch data from Home Assignment API
        static_data = fetch_static_data(venue_slug)
        dynamic_data = fetch_dynamic_data(venue_slug)

        # Extract venue coordinates
        venue_coords = static_data["venue_raw"]["location"]["coordinates"]
        venue_lon, venue_lat = venue_coords

        # Calculate delivery distance
        distance = calculate_distance(user_lat, user_lon, venue_lat, venue_lon)

        # Check delivery feasibility
        distance_ranges = dynamic_data["venue_raw"]["delivery_specs"]["delivery_pricing"]["distance_ranges"]
        base_price = dynamic_data["venue_raw"]["delivery_specs"]["delivery_pricing"]["base_price"]
        min_cart_value = dynamic_data["venue_raw"]["delivery_specs"]["order_minimum_no_surcharge"]

        delivery_fee = None
        for range_ in distance_ranges:
            if range_["min"] <= distance < range_["max"] or range_["max"] == 0:
                delivery_fee = base_price + range_["a"] + round(range_["b"] * distance / 10)
                break

        if delivery_fee is None:
            return jsonify({"error": "Delivery not possible for this distance"}), 400

        # Calculate small order surcharge
        small_order_surcharge = max(0, min_cart_value - cart_value)

        # Total price
        total_price = cart_value + small_order_surcharge + delivery_fee

        # Construct response
        response = {
            "total_price": total_price,
            "small_order_surcharge": small_order_surcharge,
            "cart_value": cart_value,
            "delivery": {
                "fee": delivery_fee,
                "distance": distance
            }
        }
        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)

