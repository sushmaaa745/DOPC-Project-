# Delivery Order Price Calculator (DOPC)

## Overview
A backend service that calculates delivery order prices using cart value, user location, and venue data.

## Installation
1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd DOPC

